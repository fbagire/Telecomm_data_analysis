# Telecomm_data_analysis

My employer wants me to provide a report to analyse opportunities for growth and make a recommendation on whether TellCo is worth buying or selling.  In this exercise, I will do this by analysing a telecommunication dataset that contains useful information about the customers & their activities on the network. The insights will be used to generate a report and a user-friendly dashboard hosted on one cloud framework.
